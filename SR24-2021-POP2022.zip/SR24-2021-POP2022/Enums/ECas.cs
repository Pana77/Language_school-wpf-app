﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SR24_2021_POP2022.Models
{
    public enum ECas
    {
        REZERVISAN, SLOBODAN
    }
}
